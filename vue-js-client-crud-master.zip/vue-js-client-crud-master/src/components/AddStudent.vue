<template>
  <div class="submit-form">
    <div v-if="!submitted">
      <div class="form-group">
        <label for="firstName">First Name</label>
        <input
          type="text"
          class="form-control"
          id="firstName"
          required
          v-model="student.firstName"
          name="firstName"
        />
      </div>

      <div class="form-group">
        <label for="lastName">Last Name</label>
        <input
          class="form-control"
          id="lastName"
          required
          v-model="student.lastName"
          name="lastName"
        />
      </div>
      <div class="form-group">
        <label for="dateOfBirth">Date Of Birth</label>
        <input
          class="form-control"
          id="dateOfBirth"
          required
          v-model="student.dateOfBirth"
          name="dateOfBirth"
        />
      </div>
      <div class="form-group">
        <label for="cellNumber">Cell Number</label>
        <input
          class="form-control"
          id="cellNumber"
          required
          v-model="student.cellNumber"
          name="cellNumber"
        />
      </div>
      <div class="form-group">
        <label for="emailAddress">Email Address</label>
        <input
          class="form-control"
          id="emailAddress"
          required
          v-model="student.emailAddress"
          name="emailAddress"
        />
      </div>
      <div class="form-group">
        <label for="currentScore">currentScore</label>
        <input type="number" class="form-control" id="currentScore"  min="0" max="100"/>
      </div>

      <button @click="saveStudent" class="btn btn-success">Submit</button>
    </div>

    <div v-else>
      <h4>You submitted successfully!</h4>
      <button class="btn btn-success" @click="newStudent">Add</button>
    </div>
  </div>
</template>

<script>
import StudentsDataService from "../services/StudentsDataService";

export default {
  name: "add-student",
  data() {
    return {
      student: {
        firstName: "",
        lastName: "",
        dateOfBirth: "",
        cellNumber: "",
        emailAddress: "",
        currentScore:0
      },
      submitted: false
    };
  },
  methods: {
    saveStudent() {
      var data = {
        firstName: this.student.firstName,
        lastName: this.student.lastName,
        dateOfBirth: this.student.dateOfBirth,
        cellNumber: this.student.cellNumber,
        emailAddress: this.student.emailAddress,
        currentScore: this.student.currentScore
      };
console.log(data);
      StudentsDataService.create(data)
        .then(response => {
          this.student.id = response.data.id;
          console.log(response.data);
          this.submitted = true;
        })
        .catch(e => {
          console.log(e);
        });
    },
    
    newStudent() {
      this.submitted = false;
      this.student = {};
    }
  }
};
</script>

<style>
.submit-form {
  max-width: 300px;
  margin: auto;
}
</style>
