<template>
  <div class="list row">
    
    <div class="col-md-6">
      <h4>Students List</h4>
      <ul class="list-group">
        <li class="list-group-item"
          :class="{ active: index == currentIndex }"
          v-for="(student, index) in students"
          :key="index"
          @click="setActiveStudent(student, index)"
        >
          {{ student.firstName }}
        </li>
      </ul>

    </div>
    <div class="col-md-6">
      <div v-if="currentStudent">
        <h4>[Profile]</h4>
        <div>
          <label><strong></strong></label> 
        </div>
        <div>
          <label><strong>FirstName:</strong></label> <div class="form-group">
        <input type="text" class="form-control" id="firstName"
          v-model="currentStudent.firstName"
        />
      </div>
        </div>
        <div>
          <label><strong>LastName:</strong></label> <div class="form-group">
        <input type="text" class="form-control" id="lastName"
          v-model="currentStudent.lastName"
        />
      </div>
        </div>
        <div>
          <label><strong>Date Of Birth:</strong></label> <div class="form-group">
        <input type="text" id="dateOfBirth" name="dateOfBirth"
    v-model="currentStudent.dateOfBirth" readonly/>
      </div>
        </div>
        <div>
          <label><strong>Cell Number:</strong></label> <div class="form-group">
        <input type="text" class="form-control" id="cellNumber"
          v-model="currentStudent.cellNumber"/>
      </div>
        </div>
        <div>
          <label><strong>Email Address:</strong></label><div class="form-group">
        <input type="text" class="form-control" id="emailAddress"
          v-model="currentStudent.emailAddress"/>
      </div>
        </div>
        <div>
          <label><strong>Current Score:</strong></label> <div class="form-group">
        <input type="number" class="form-control" id="currentScore"  min="0" max="100"
        v-model="currentStudent.currentScore"/>
      </div>
        </div>
        <div>
          <label><strong>Average Score:</strong></label> <div class="form-group">
        <input type="text" id="averageScore" name="averageScore"
    v-model="currentStudent.averageScore" readonly/>
      </div>
        </div>

         <button class="m-3 btn btn-sm btn-warning" @click="updateStudent()">
        Update
      </button>
        <button class="m-3 btn btn-sm btn-danger" @click="removeStudents(currentStudent)">
        Delete
      </button>
        
      </div>
      <div v-else>
        <br />
        <p>Please click on a Student...</p>
      </div>
    </div>
  </div>
</template>

<script>
import StudentsDataService from "../services/StudentsDataService";

export default {
  name: "students-list",
  data() {
    return {
      students: [],
      currentStudent: null,
      currentIndex: -1,
      title: ""
    };
  },
  methods: {
    retrieveStudents() {
      StudentsDataService.getAll()
        .then(response => {
          this.students = response.data;
          console.log(response.data);
        })
        .catch(e => {
          console.log(e);
        });
    },

    refreshList() {
      this.retrieveStudents();
      this.currentStudent = null;
      this.currentIndex = -1;
    },

    setActiveStudent(student, index) {
      this.currentStudent = student;
      this.currentIndex = index;
    },
	updateStudent() {
      StudentsDataService.update(this.currentStudent)
        .then(response => {
          console.log(response.data);
          this.message = 'The Student was updated successfully!';
        })
        .catch(e => {
          console.log(e);
        });
    },
    removeStudents(student) {
    console.log(student);
      StudentsDataService.delete(student)
        .then(response => {
          console.log(response.data);
          this.refreshList();
        })
        .catch(e => {
          console.log(e);
        });
    }
  },
  mounted() {
    this.retrieveStudents();
  }
};
</script>

<style>
.list {
  text-align: left;
  max-width: 750px;
  margin: auto;
}
</style>
