import http from "../http-common";

class StudentsDataService {
  getAll() {
    return http.get("/student/findAllStudents");
  }

	getStudent(data){
	return http.get("/student/getStudent",data);
	}
	create(data) {
		return http.post("/student/save", data);
	}

	update(data) {
		return http.put(`/student/update/`, data);
	}

	updatescore(data) {
		return http.put(`/student/updatescore`,data);
	}

	delete(data) {
		return http.post(`/student/delete`,data);
	}

}

export default new StudentsDataService();
