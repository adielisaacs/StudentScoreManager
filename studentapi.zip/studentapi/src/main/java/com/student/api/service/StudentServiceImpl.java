package com.student.api.service;

import com.student.api.model.Student;
import com.student.api.repository.StudentRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentRepository studentRepository;
    
    @Autowired
    JdbcTemplate jdbcTemplate;
	
	@Override
	public Student saveStudent(Student student) {
		// TODO Auto-generated method stub
		
		studentRepository.save(student);
		return student;
	}

	@Override
	public Student updateStudent(Student student) {
		// TODO Auto-generated method stub
		studentRepository.save(student);

		return student;
	}
	
	
	@Override
	public void deleteStudent(Student student) {
		// TODO Auto-generated method stub
		studentRepository.delete(student);
	}

	@Override
	public List<Student> findAllStudents() {
		// TODO Auto-generated method stub
		return studentRepository.findAll();
	}

	@Override
	public List<Student> findByStudentFirstnameSurname(Student student) {
		// TODO Auto-generated method stub
		List<Student> result = jdbcTemplate.query("select * from student where firstname= ? and lastname=?", new Object[] {
				 student.getFirstName() , student.getLastName()
		        },
		        new BeanPropertyRowMapper <Student> (Student.class));
		
		
		return result;
	}

	
}
