package com.student.api.controller;

import com.student.api.model.Student;
import com.student.api.service.StudentService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


import java.security.Principal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import javax.ws.rs.Consumes;
import javax.ws.rs.core.MediaType;

@CrossOrigin(origins = "http://localhost:8080/", maxAge = 3600)
@RestController
public class StudentController {

    @Autowired
    private StudentService studentService;

    @PostMapping("/student/save")
    public ResponseEntity<Student> saveStudent(@RequestBody Student student){
    	
    	List<Student> students = studentService.findByStudentFirstnameSurname(student);
    	if(Optional.ofNullable(students.size()).orElse(0) > 0){
             return new ResponseEntity<>(HttpStatus.CONFLICT);
        }else {
         	student.setStudentNumber(new Integer((int)(Math.random() * 2020111) + 2020111));
         	student.setAverageScore(student.getCurrentScore());
         	studentService.saveStudent(student);
            return new ResponseEntity<Student>(student, HttpStatus.CREATED);
        }
    	 
    }
    
    @PutMapping("/student/update")
    public ResponseEntity<?> updateStudent(@RequestBody Student student){
    	int average = averageScore(student);
    	
    	if(Optional.ofNullable(average).orElse(0) == 0) { 
    		student.setAverageScore(student.getCurrentScore()); 
    	}else { 
    		student.setAverageScore(average);
    	}
    	student.setAverageScore(average);
    	Student modifiedstudent = studentService.updateStudent(student);
    	
    	if(Optional.ofNullable(modifiedstudent) != null){
    		return new ResponseEntity<>(modifiedstudent, HttpStatus.ACCEPTED);	
    	}else {
    		return new ResponseEntity<>(student, HttpStatus.NOT_MODIFIED);
    	}
        
    }
    
    @PutMapping("/student/updatescore")
    public ResponseEntity<?> updateStudentScore(@RequestBody Student student){
    	
    	int average = averageScore(student);
    	
    	student.setAverageScore(average);
    	
    	Student modifiedstudent = studentService.updateStudent(student);
    	
    	if(Optional.ofNullable(modifiedstudent) != null){
    		return new ResponseEntity<>(modifiedstudent, HttpStatus.ACCEPTED);	
    	}else {
    		return new ResponseEntity<>(student, HttpStatus.NOT_MODIFIED);
    	}
        
    }
    
	
    @GetMapping("/student/findAllStudents")
    public ResponseEntity<?> findAllStudents(){
    	
    	List<Student> studentrecords = studentService.findAllStudents();
    	if(Optional.ofNullable(studentrecords) == null || Optional.ofNullable(studentrecords.size()).orElse(0) <= 0){
    		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    	}else {
            return new ResponseEntity<>(studentrecords, HttpStatus.OK);

    	}
    }
    
    @PostMapping("/student/getstudent")
    public ResponseEntity<?> getStudent(@RequestBody Student student){
    	
    	List<Student> students = studentService.findByStudentFirstnameSurname(student);
    	return new ResponseEntity<>(students.get(0), HttpStatus.OK);    
    }
    
    @PostMapping("/student/delete")
    public ResponseEntity<?> deleteStudent(@RequestBody Student student){
    	studentService.deleteStudent(student);
    	return new ResponseEntity<>(HttpStatus.OK);
    }
    
    
    public int averageScore(Student student) {
    	
    	List<Student> students = studentService.findByStudentFirstnameSurname(student);
    	int averagescore = 0;
    	int scoreSum = 0;
    	int  countScore = 0;

    	scoreSum = students.stream().mapToInt(o -> o.getCurrentScore()).sum();
    	countScore = (int) students.stream().mapToInt(o -> o.getCurrentScore()).count();
 
    	scoreSum += student.getCurrentScore();
    	countScore++;
    	
    	averagescore = (int) Math.round(scoreSum/countScore);
    	
    	return averagescore;
    }
        
}
